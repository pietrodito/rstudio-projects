dir_create("./inst/htmlwidgets/tabulator", recurse = TRUE)

