# Notes about tabulator package

-   tabulator aims to integrate `tabulator.js` as a shiny widget

