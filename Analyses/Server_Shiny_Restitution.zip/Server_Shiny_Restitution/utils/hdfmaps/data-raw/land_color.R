land_color <- c('antiquewhite1')

usethis::use_data(land_color, overwrite = TRUE)
