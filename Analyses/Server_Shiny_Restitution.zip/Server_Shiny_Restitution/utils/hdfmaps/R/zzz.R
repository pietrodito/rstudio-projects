.onAttach <- function(...) {
 library(tidyverse)
 library(readr)
 library(readxl)
 library(sf)
 library(ggrepel)
 library(rnaturalearth)
 library(ggforce)
 library(scales)
 library(ggrepel)
 library(magrittr)
 library(purrr)
}
