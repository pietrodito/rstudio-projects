#' Title
#'
#' @return
#' @export
#'
#' @examples
theme_alice <- function() {
  theme_void() + theme(panel.background = element_rect(fill = 'aliceblue'))
}
